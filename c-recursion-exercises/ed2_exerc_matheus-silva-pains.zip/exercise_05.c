#include <stdio.h>

double soma_serie(int n) {
    if (n <= 0) {
        return 0.0;
    }
    if (n == 1) {
        return 1.0;
    }
    return (1.0 / n) + soma_serie(n - 1);
}

int main() {
    int n;
    printf("N: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("O número precisa ser > 0\n");
    } else {
        double resultado = soma_serie(n);
        printf("A soma é %f.\n", n, resultado);
    }

    return 0;
}
